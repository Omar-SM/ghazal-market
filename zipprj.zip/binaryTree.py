class Node:
    def __init__(self, data=None):
        self.data = data
        self.left = None
        self.right = None
        self.Brand=None
class BrandNode:
    def __init__(self,data=None):
        self.data=data
        self.next=None
        self.product=None
class productNode:
    def __init__(self,data=None):
        self.data=data
        self.next=None
class Categroy:
    def __init__(self):
        self.root = None
        self.current = None

    def inorderTraverse(self, node): # Depth First
        if node != None:
            self.inorderTraverse(node.left)
            print(node.data, " ")
            self.inorderTraverse(node.right)
    
    def preorderTraverse(self, node): # Depth First
        if node != None:
            print(node.data, " ")
            self.preorderTraverse(node.left)
            self.preorderTraverse(node.right)
    
    def postorderTraverse(self, node): # Depth First
        if node != None:
            self.postorderTraverse(node.left)
            self.postorderTraverse(node.right)
            print(node.data, " ")

    def defineRoot(self, data):
        if self.root == None:
            newNode = Node(data)
            self.root = newNode
        else:
            print("Root already inserted")

    def insert(self, node, option, data):
        if node != None:
            newNode = Node(data)
            if option == "left" and node.left == None:
                node.left = newNode
            elif option == "right" and node.right == None:
                node.right = newNode
            else:
                print("Enter a valid insert commmand")

    def printLeafNodes(self, node):
       if node.left!=None or node.right!=None:
           if node.left!=None and node.right==None:
            self.printLeafNodes(node.left)
           elif node.right!=None and node.left==None:
            self.printLeafNodes(node.right)
           elif node.left!=None and node.right!=None:
             self.printLeafNodes(node.left)
             self.printLeafNodes(node.right)
       else :
           print(node.data , " ")  
