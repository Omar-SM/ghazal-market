class node():
    def __init__(self,data=None):
        self.data=data
        self.next=None
class LinkList():
    def __init__(self):
        self.head=None
        self.current=None
        self.tail=None

    def tailmarker(self):   #this method is used to mark the tail of the list
        self.current=self.head
        while self.current is not None:
            if self.current.next is None:
                self.tail=self.current
            self.current=self.current.next

    def trav(self):
        self.current=self.head
        while self.current is not None:
            print(self.current.data)
            self.current=self.current.next

    def insert(self, data):
        n=node(data)
        if self.head is None:
            self.head =n
            self.current = n
            self.tail=n
        else:
            if self.current is None:
                self.current = self.head
                n.next = self.current.next
                self.current.next = n
                self.current = n
                if n.next is None:
                    self.tail=n
        """
            self.current = self.head
            while self.current.next is not None:
                self.current = self.current.next
            self.tail = self.current
        """
    def append(self,data):
        n=node(data)
        self.tailmarker()
        if self.head is None:
            self.head=n
            self.current=n
            self.tail=n
        else:
            self.tail.next = n
            self.tail = n
            self.current = n
    
    def remove(self,data):
        rem_data=None
        prev=self.head
        self.current=self.head
        while self.current!=data:
            if self.current.data==data:
                rem_data=data
                prev.next=self.current.next
                self.current.next=None
                print("the removed data : "+str(rem_data))
                return
            else:
                if self.current.next is None:
                    print("there is no such data to remove")
                    break
                else:
                    prev=self.current
                    self.current=self.current.next
    def clear(self):
        self.head=None
        self.current=self.head
        self.tail=self.head
    
    def length(self):
        count=0
        self.current=self.head
        while self.current is not None:
            count+=1
            self.current=self.current.next
        return count
    def last(self):
        self.current=self.head
        while self.current is not None:
            if self.current.next is None:
                self.tail=self.current
            self.current=self.current.next
        return self.tail.data
    
    def setCurrentByIndex(self,index):
        count=0
        if index==0:
            self.current=self.head
        else:
            self.current=self.head
            while self.current is not None:
                if count==index:
                    return self.current
                else:
                    count+=1
                    self.current=self.current.next
            return print("out of index ")
    def setCurrentByValue(self,Value):
        if Value is None:
            self.current=self.head
        else:
            self.current=self.head
            while self.current is not None:
                if self.current.data==Value:
                    return self.current
                else:
                    self.current=self.current.next
            return print("out of index ")
    